# Volume-Scroll
Chrome extension for changing video volume by scrolling

Now available on the chrome webstore:

https://chrome.google.com/webstore/detail/volume-scroll/gkmagiadkkhdilnaicdnngcjhmhaeaoh
